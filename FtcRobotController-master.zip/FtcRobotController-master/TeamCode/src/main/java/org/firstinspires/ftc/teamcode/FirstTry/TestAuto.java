package org.firstinspires.ftc.teamcode.FirstTry;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "test auto")

//test for red carousel side
public class TestAuto extends LinearOpMode{
    AutoHardware robot = new AutoHardware();

    //lol
    int dontKnow;

    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap);

        robot.grab();

        telemetry.addData("Status", "Initialized");
        telemetry.update();

        robot.frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        robot.frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        waitForStart();

        //movements for auto
        //move forward
        robot.driveAndStop(28, .7, this);

        //rotate
        robot.rotate(-135,.7,this);

        //move arm up to level
        robot.moveArm(3,.5,this);

        //move forward?
        //robot.driveAndStop(dontKnow, 1, this);

        //release
        robot.release();
        sleep(2000);

        //move back
        //robot.driveAndStop(-dontKnow, 1, this);

        //return arm
        robot.moveArm(0,.5,this);

        //rotate to park
        robot.rotate(45,.7,this);

        //drive to park zone
        robot.driveAndStop(28,.8,this);

        //stop robot
        robot.stop();
    }
}