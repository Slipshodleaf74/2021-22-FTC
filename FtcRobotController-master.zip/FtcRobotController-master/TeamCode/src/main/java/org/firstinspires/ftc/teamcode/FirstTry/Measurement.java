package org.firstinspires.ftc.teamcode.FirstTry;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "measuring code")
public class Measurement extends LinearOpMode{
    AutoHardware robot = new AutoHardware();

    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap);
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        int pos;
        int pos2;
        double rot;

        waitForStart();
        while(opModeIsActive()){
            pos = robot.frontRight.getCurrentPosition();
            pos2 = robot.arm.getCurrentPosition();
            rot = robot.getAngle();
            telemetry.addData("wheel position:", Integer.toString(pos));
            telemetry.addData("arm position:", Integer.toString(pos2));
            telemetry.addData("angle:", Double.toString(rot));
            telemetry.update();
        }
    }
}
