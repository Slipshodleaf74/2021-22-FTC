package org.firstinspires.ftc.teamcode.FirstTry;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

@TeleOp(name = "Andrew Opmode", group = "TeleOp")
public class AndrewCode extends LinearOpMode{

    //initialize opmode members
    AndrewHardware robot = new AndrewHardware();
    private ElapsedTime runtime = new ElapsedTime();

    //initialize
    @Override
    public void runOpMode(){
        robot.init(hardwareMap);
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        /*
        telemetry.addData("Mode", "calibrating...");
        telemetry.update();

        // make sure the imu gyro is calibrated before continuing.
        while (!isStopRequested() && !robot.imu.isGyroCalibrated())
        {
            sleep(50);
            idle();
        }
        */

        waitForStart();
        runtime.reset();

        //variables for controlling
        double forward, strafe, rotate, armMove;
        double correction = 0; //dunno abt this one, maybe useful for autonomoosssss
        double armSpeed = 0.4;
        double carouselSpeed = 0.5;
        double grabPos = 0.4;
        double openPos = 0.0;

        double sens = 0.3;

        //control loop
        while(opModeIsActive()){

            forward = Range.clip(gamepad1.left_stick_y,-1,1);
            strafe = Range.clip(gamepad1.left_stick_x,-1,1);
            rotate = Range.clip(gamepad1.right_stick_x,-1,1);

            armMove = Range.clip(gamepad2.left_stick_y,-1,1);

            //move wheels
            if(Math.abs(forward) > sens || Math.abs(strafe) > sens || Math.abs(rotate) > sens){
                robot.setDriveSpeeds(forward, strafe, rotate, correction);
            }
            else{
                robot.stop();
            }

            //move arm
            if(Math.abs(armMove) > sens){
                robot.moveArm(armMove * armSpeed);
            }
            else{
                robot.moveArm(0);
            }

            //control grabber
            if(gamepad2.left_bumper){
                robot.grab(grabPos);
            }
            else if(gamepad2.right_bumper) {
                robot.grab(openPos);
            }

            if(gamepad2.a){
                robot.spin(carouselSpeed, true);
            }
            else if(gamepad2.b){
                robot.spin(carouselSpeed, false);
            }
            else{
                robot.spin(0, true);
            }

        }
    }
}
